import React from "react";
import "./Insight.css";

export default function Insight() {
  return (
    <div>
      <main className="container">
      </main>
    </div>
  );
}
