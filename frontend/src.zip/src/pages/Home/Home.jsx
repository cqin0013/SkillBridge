import Hero from "./Hero/Hero";

export default function Home() {
  return (
    <main className="home">
      <Hero />
    </main>
  );
}
