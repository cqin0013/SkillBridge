import React from "react";
import AnalyzerWizard from "./AnalyzerWizard";

export default function Analyzer() {
  return <AnalyzerWizard />;
}
