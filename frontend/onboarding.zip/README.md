# React + Vite
npm install
npm run dev
